// Admin Dashboard JavaScript
const ADMIN_WALLET = '0x14b66774d1eec557ff19dd637a0208a098c017be';
let web3;
let currentAccount;
let projects = [];
let messages = [];
let socialInfo = {};

// Initialize the admin application
document.addEventListener('DOMContentLoaded', function() {
    feather.replace();
    initializeParticles();
    initializeAuth();
    initializeDashboard();
});

// Initialize particles background
function initializeParticles() {
    if (typeof particlesJS !== 'undefined') {
        particlesJS('particles-js', {
            particles: {
                number: { value: 50, density: { enable: true, value_area: 800 } },
                color: { value: ['#00D4FF', '#7B2CBF', '#FF2E82'] },
                shape: { type: 'circle' },
                opacity: { value: 0.3, random: true },
                size: { value: 2, random: true },
                line_linked: {
                    enable: true,
                    distance: 100,
                    color: '#00D4FF',
                    opacity: 0.2,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 1,
                    direction: 'none',
                    random: false,
                    straight: false,
                    out_mode: 'out',
                    bounce: false
                }
            },
            interactivity: {
                detect_on: 'canvas',
                events: {
                    onhover: { enable: false, mode: 'repulse' },
                    onclick: { enable: false, mode: 'push' },
                    resize: true
                }
            },
            retina_detect: true
        });
    }
}

// Authentication system
function initializeAuth() {
    const connectMetaMask = document.getElementById('connect-metamask');
    const connectWalletConnect = document.getElementById('connect-walletconnect');
    const disconnectWallet = document.getElementById('disconnect-wallet');
    const connectionStatus = document.getElementById('connection-status');

    connectMetaMask.addEventListener('click', async () => {
        try {
            if (typeof window.ethereum !== 'undefined') {
                web3 = new Web3(window.ethereum);
                await window.ethereum.request({ method: 'eth_requestAccounts' });
                const accounts = await web3.eth.getAccounts();
                
                if (accounts.length > 0) {
                    currentAccount = accounts[0].toLowerCase();
                    if (currentAccount === ADMIN_WALLET.toLowerCase()) {
                        showDashboard();
                    } else {
                        connectionStatus.textContent = 'Access denied. Invalid wallet address.';
                        connectionStatus.className = 'mt-6 text-center text-sm text-red-500';
                    }
                }
            } else {
                connectionStatus.textContent = 'MetaMask not detected. Please install MetaMask.';
                connectionStatus.className = 'mt-6 text-center text-sm text-red-500';
            }
        } catch (error) {
            console.error('Connection failed:', error);
            connectionStatus.textContent = 'Connection failed. Please try again.';
            connectionStatus.className = 'mt-6 text-center text-sm text-red-500';
        }
    });

    disconnectWallet.addEventListener('click', () => {
        currentAccount = null;
        web3 = null;
        showLogin();
    });
}

// Show dashboard after successful authentication
function showDashboard() {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    document.getElementById('wallet-address').textContent = currentAccount;
    
    // Load dashboard data
    loadDashboardData();
}

// Show login screen
function showLogin() {
    document.getElementById('login-screen').classList.remove('hidden');
    document.getElementById('dashboard').classList.add('hidden');
}

// Initialize dashboard functionality
function initializeDashboard() {
    // Navigation
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const section = item.dataset.section;
            showSection(section);
            
            // Update active nav item
            navItems.forEach(nav => {
                nav.classList.remove('active', 'text-neon-blue', 'bg-neon-blue/20');
                nav.classList.add('text-gray-300');
            });
            item.classList.add('active', 'text-neon-blue', 'bg-neon-blue/20');
            item.classList.remove('text-gray-300');
        });
    });

    // Project management
    initializeProjectManagement();
    
    // Social info form
    initializeSocialForm();
}

// Show specific dashboard section
function showSection(sectionName) {
    const sections = document.querySelectorAll('.dashboard-section');
    sections.forEach(section => section.classList.add('hidden'));
    
    document.getElementById(`section-${sectionName}`).classList.remove('hidden');
    
    // Load section-specific data
    switch(sectionName) {
        case 'overview':
            loadOverviewData();
            break;
        case 'projects':
            loadProjects();
            break;
        case 'messages':
            loadMessages();
            break;
        case 'social':
            loadSocialInfo();
            break;
        case 'analytics':
            loadAnalytics();
            break;
    }
}

// Load dashboard data
async function loadDashboardData() {
    try {
        // Load projects
        const projectsResponse = await fetch('/api/projects');
        if (projectsResponse.ok) {
            projects = await projectsResponse.json();
        }
        
        // Load messages
        const messagesResponse = await fetch('/api/contact-submissions');
        if (messagesResponse.ok) {
            messages = await messagesResponse.json();
        }
        
        // Load social info
        const socialResponse = await fetch('/api/social-info');
        if (socialResponse.ok) {
            socialInfo = await socialResponse.json();
        }
        
        // Update overview stats
        updateOverviewStats();
        
    } catch (error) {
        console.error('Failed to load dashboard data:', error);
    }
}

// Update overview statistics
function updateOverviewStats() {
    document.getElementById('total-projects').textContent = projects.length;
    document.getElementById('new-messages').textContent = messages.filter(m => m.status === 'new').length;
    // Add more stats as needed
}

// Load overview data
function loadOverviewData() {
    updateOverviewStats();
    
    // Load recent activity
    const recentActivity = document.getElementById('recent-activity');
    recentActivity.innerHTML = '';
    
    // Combine recent messages and projects for activity feed
    const activities = [
        ...messages.slice(0, 3).map(msg => ({
            type: 'message',
            text: `New message from ${msg.name}`,
            time: new Date(msg.createdAt).toLocaleDateString()
        })),
        ...projects.slice(0, 2).map(project => ({
            type: 'project',
            text: `Project "${project.title}" updated`,
            time: new Date(project.updatedAt).toLocaleDateString()
        }))
    ];
    
    activities.forEach(activity => {
        const activityItem = document.createElement('div');
        activityItem.className = 'flex items-center justify-between p-3 bg-dark-bg rounded-md';
        activityItem.innerHTML = `
            <div class="flex items-center">
                <i data-feather="${activity.type === 'message' ? 'mail' : 'folder'}" class="w-4 h-4 text-neon-blue mr-3"></i>
                <span class="text-gray-300">${activity.text}</span>
            </div>
            <span class="text-sm text-gray-500">${activity.time}</span>
        `;
        recentActivity.appendChild(activityItem);
    });
    
    feather.replace();
}

// Project management
function initializeProjectManagement() {
    const addProjectBtn = document.getElementById('add-project-btn');
    const projectModal = document.getElementById('project-modal');
    const closeModal = document.getElementById('close-modal');
    const cancelModal = document.getElementById('cancel-modal');
    const projectForm = document.getElementById('project-form');

    addProjectBtn.addEventListener('click', () => {
        openProjectModal();
    });

    closeModal.addEventListener('click', closeProjectModal);
    cancelModal.addEventListener('click', closeProjectModal);

    projectForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await saveProject();
    });

    // Close modal on outside click
    projectModal.addEventListener('click', (e) => {
        if (e.target === projectModal) {
            closeProjectModal();
        }
    });
}

// Open project modal
function openProjectModal(project = null) {
    const modal = document.getElementById('project-modal');
    const title = document.getElementById('modal-title');
    const form = document.getElementById('project-form');
    
    if (project) {
        title.textContent = 'Edit Project';
        populateProjectForm(project);
    } else {
        title.textContent = 'Add Project';
        form.reset();
        document.getElementById('project-id').value = '';
    }
    
    modal.classList.remove('hidden');
}

// Close project modal
function closeProjectModal() {
    document.getElementById('project-modal').classList.add('hidden');
}

// Populate project form with existing data
function populateProjectForm(project) {
    document.getElementById('project-id').value = project.id;
    document.getElementById('project-title').value = project.title;
    document.getElementById('project-description').value = project.description;
    document.getElementById('project-url').value = project.url;
    document.getElementById('project-category').value = project.category;
    document.getElementById('project-tags').value = project.tags;
    document.getElementById('project-featured').checked = project.featured;
}

// Save project
async function saveProject() {
    const formData = {
        title: document.getElementById('project-title').value,
        description: document.getElementById('project-description').value,
        url: document.getElementById('project-url').value,
        category: document.getElementById('project-category').value,
        tags: document.getElementById('project-tags').value,
        featured: document.getElementById('project-featured').checked
    };
    
    const projectId = document.getElementById('project-id').value;
    
    try {
        const method = projectId ? 'PUT' : 'POST';
        const url = projectId ? `/api/projects/${projectId}` : '/api/projects';
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });
        
        if (response.ok) {
            closeProjectModal();
            loadProjects();
            showNotification('Project saved successfully!', 'success');
        } else {
            showNotification('Failed to save project', 'error');
        }
    } catch (error) {
        console.error('Error saving project:', error);
        showNotification('Error saving project', 'error');
    }
}

// Load projects
async function loadProjects() {
    try {
        const response = await fetch('/api/projects');
        if (response.ok) {
            projects = await response.json();
            renderProjects();
        }
    } catch (error) {
        console.error('Error loading projects:', error);
    }
}

// Render projects list
function renderProjects() {
    const projectsList = document.getElementById('projects-list');
    projectsList.innerHTML = '';
    
    projects.forEach(project => {
        const projectCard = document.createElement('div');
        projectCard.className = 'bg-dark-card border border-neon-blue/30 rounded-lg p-4';
        projectCard.innerHTML = `
            <div class="flex items-center justify-between">
                <div class="flex-1">
                    <div class="flex items-center mb-2">
                        <h3 class="text-lg font-semibold text-neon-blue">${project.title}</h3>
                        ${project.featured ? '<span class="ml-2 px-2 py-1 text-xs bg-neon-pink text-white rounded">Featured</span>' : ''}
                    </div>
                    <p class="text-gray-300 mb-2">${project.description}</p>
                    <div class="flex items-center space-x-4 text-sm text-gray-400">
                        <span>Category: ${project.category}</span>
                        <span>Views: ${project.viewCount || 0}</span>
                        <a href="${project.url}" target="_blank" class="text-neon-blue hover:underline">View Project</a>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <button onclick="editProject(${project.id})" class="p-2 text-neon-blue hover:bg-neon-blue/20 rounded">
                        <i data-feather="edit" class="w-4 h-4"></i>
                    </button>
                    <button onclick="deleteProject(${project.id})" class="p-2 text-red-500 hover:bg-red-500/20 rounded">
                        <i data-feather="trash-2" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>
        `;
        projectsList.appendChild(projectCard);
    });
    
    feather.replace();
}

// Edit project
function editProject(id) {
    const project = projects.find(p => p.id === id);
    if (project) {
        openProjectModal(project);
    }
}

// Delete project
async function deleteProject(id) {
    if (confirm('Are you sure you want to delete this project?')) {
        try {
            const response = await fetch(`/api/projects/${id}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                loadProjects();
                showNotification('Project deleted successfully!', 'success');
            } else {
                showNotification('Failed to delete project', 'error');
            }
        } catch (error) {
            console.error('Error deleting project:', error);
            showNotification('Error deleting project', 'error');
        }
    }
}

// Load messages
async function loadMessages() {
    try {
        const response = await fetch('/api/contact-submissions');
        if (response.ok) {
            messages = await response.json();
            renderMessages();
        }
    } catch (error) {
        console.error('Error loading messages:', error);
    }
}

// Render messages
function renderMessages() {
    const messagesList = document.getElementById('messages-list');
    messagesList.innerHTML = '';
    
    messages.forEach(message => {
        const messageCard = document.createElement('div');
        messageCard.className = `bg-dark-card border rounded-lg p-4 ${
            message.status === 'new' ? 'border-neon-blue' : 'border-gray-600'
        }`;
        messageCard.innerHTML = `
            <div class="flex items-start justify-between">
                <div class="flex-1">
                    <div class="flex items-center mb-2">
                        <h3 class="text-lg font-semibold text-neon-blue">${message.name}</h3>
                        <span class="ml-2 px-2 py-1 text-xs rounded ${
                            message.status === 'new' ? 'bg-neon-blue text-white' : 
                            message.status === 'read' ? 'bg-yellow-500 text-black' : 
                            'bg-green-500 text-white'
                        }">${message.status}</span>
                    </div>
                    <p class="text-gray-300 mb-2"><strong>Subject:</strong> ${message.subject}</p>
                    <p class="text-gray-300 mb-2"><strong>Email:</strong> ${message.email}</p>
                    <p class="text-gray-400">${message.message}</p>
                    <p class="text-sm text-gray-500 mt-2">${new Date(message.createdAt).toLocaleString()}</p>
                </div>
                <div class="flex items-center space-x-2">
                    <select onchange="updateMessageStatus(${message.id}, this.value)" class="bg-dark-bg border border-neon-blue/30 rounded px-2 py-1 text-sm text-white">
                        <option value="new" ${message.status === 'new' ? 'selected' : ''}>New</option>
                        <option value="read" ${message.status === 'read' ? 'selected' : ''}>Read</option>
                        <option value="replied" ${message.status === 'replied' ? 'selected' : ''}>Replied</option>
                    </select>
                    <button onclick="deleteMessage(${message.id})" class="p-2 text-red-500 hover:bg-red-500/20 rounded">
                        <i data-feather="trash-2" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>
        `;
        messagesList.appendChild(messageCard);
    });
    
    feather.replace();
}

// Update message status
async function updateMessageStatus(id, status) {
    try {
        const response = await fetch(`/api/contact-submissions/${id}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ status })
        });
        
        if (response.ok) {
            loadMessages();
            showNotification('Message status updated!', 'success');
        }
    } catch (error) {
        console.error('Error updating message status:', error);
    }
}

// Delete message
async function deleteMessage(id) {
    if (confirm('Are you sure you want to delete this message?')) {
        try {
            const response = await fetch(`/api/contact-submissions/${id}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                loadMessages();
                showNotification('Message deleted successfully!', 'success');
            }
        } catch (error) {
            console.error('Error deleting message:', error);
        }
    }
}

// Social info form
function initializeSocialForm() {
    const socialForm = document.getElementById('social-form');
    socialForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await saveSocialInfo();
    });
}

// Load social info
async function loadSocialInfo() {
    try {
        const response = await fetch('/api/social-info');
        if (response.ok) {
            const data = await response.json();
            populateSocialForm(data);
        }
    } catch (error) {
        console.error('Error loading social info:', error);
    }
}

// Populate social form
function populateSocialForm(data) {
    document.getElementById('twitter-url').value = data.twitterUrl || '';
    document.getElementById('discord-url').value = data.discordUrl || '';
    document.getElementById('github-url').value = data.githubUrl || '';
    document.getElementById('telegram-url').value = data.telegramUrl || '';
    document.getElementById('contact-email').value = data.contactEmail || '';
    document.getElementById('contact-phone').value = data.contactPhone || '';
    document.getElementById('bio-description').value = data.bioDescription || '';
}

// Save social info
async function saveSocialInfo() {
    const formData = {
        twitterUrl: document.getElementById('twitter-url').value,
        discordUrl: document.getElementById('discord-url').value,
        githubUrl: document.getElementById('github-url').value,
        telegramUrl: document.getElementById('telegram-url').value,
        contactEmail: document.getElementById('contact-email').value,
        contactPhone: document.getElementById('contact-phone').value,
        bioDescription: document.getElementById('bio-description').value
    };
    
    try {
        const response = await fetch('/api/social-info', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });
        
        if (response.ok) {
            showNotification('Social information saved successfully!', 'success');
        } else {
            showNotification('Failed to save social information', 'error');
        }
    } catch (error) {
        console.error('Error saving social info:', error);
        showNotification('Error saving social information', 'error');
    }
}

// Load analytics
async function loadAnalytics() {
    try {
        const response = await fetch('/api/analytics');
        if (response.ok) {
            const analytics = await response.json();
            renderAnalytics(analytics);
        }
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

// Render analytics
function renderAnalytics(analytics) {
    const analyticsContent = document.getElementById('analytics-content');
    analyticsContent.innerHTML = `
        <div class="bg-dark-card border border-neon-blue/30 rounded-lg p-6">
            <h3 class="text-lg font-semibold text-neon-blue mb-4">Recent Events</h3>
            <div class="space-y-2">
                ${analytics.slice(0, 20).map(event => `
                    <div class="flex items-center justify-between p-2 bg-dark-bg rounded">
                        <span class="text-gray-300">${event.event}</span>
                        <span class="text-sm text-gray-500">${new Date(event.createdAt).toLocaleString()}</span>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 px-4 py-2 rounded-lg text-white ${
        type === 'success' ? 'bg-green-600' : 
        type === 'error' ? 'bg-red-600' : 'bg-blue-600'
    }`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Global functions for HTML onclick handlers
window.editProject = editProject;
window.deleteProject = deleteProject;
window.updateMessageStatus = updateMessageStatus;
window.deleteMessage = deleteMessage;