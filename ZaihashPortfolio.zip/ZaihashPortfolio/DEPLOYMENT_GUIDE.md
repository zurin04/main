# Project Zaihash - VPS Deployment Guide

This guide will help you deploy your Project Zaihash to your VPS step by step.

## Prerequisites

You'll need:
- A Ubuntu VPS (20.04 or newer)
- SSH access to your server
- A domain name (optional but recommended)
- At least 2GB RAM

## Step 1: Connect to Your Server

**Location:** Your local computer

```bash
ssh your-username@your-server-ip
```

## Step 2: Update System and Install Dependencies

**Location:** `/home/your-username` (your server's home directory)

### Step 2a: Update Your System
```bash
sudo apt update && sudo apt upgrade -y
```

### Step 2b: Install Node.js 20
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

Verify installation:
```bash
node --version
npm --version
```

### Step 2c: Install System Dependencies
```bash
sudo apt install -y postgresql postgresql-contrib nginx build-essential python3 curl wget gnupg git
```

### Step 2d: Install PM2 (Process Manager)
```bash
sudo npm install -g pm2
```

### Step 2e: Install TypeScript and Build Tools
```bash
sudo npm install -g typescript ts-node
```

## Step 3: Setup PostgreSQL Database

**Location:** `/home/your-username`

### Start PostgreSQL service:
```bash
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### Create database and user:
```bash
sudo -u postgres psql
```

In the PostgreSQL prompt, run:
```sql
CREATE USER portfolio_user WITH PASSWORD 'your_secure_password';
CREATE DATABASE project_zaihash_db OWNER portfolio_user;
GRANT ALL PRIVILEGES ON DATABASE project_zaihash_db TO portfolio_user;
\q
```

## Step 4: Create Application Directory

**Location:** `/home/your-username`

```bash
sudo mkdir -p /var/www/project-zaihash
sudo chown -R $USER:$USER /var/www/project-zaihash
```

## Step 5: Upload Your Application Files

**Location:** Your local computer (first command) and `/var/www/project-zaihash` (second command)

From your local machine, upload the project files:

```bash
# If you have the project locally
scp -r /path/to/your/project/* your-username@your-server-ip:/var/www/project-zaihash/

# Or clone from repository (if using Git)
cd /var/www/project-zaihash
git clone https://github.com/your-username/project-zaihash.git .
```

## Step 6: Configure Environment Variables

**Location:** `/var/www/project-zaihash`

Create environment file:
```bash
cd /var/www/project-zaihash
nano .env
```

Add these variables (replace with your actual values):
```env
# Database Configuration
DATABASE_URL=postgresql://portfolio_user:your_secure_password@localhost:5432/project_zaihash_db
PGHOST=localhost
PGPORT=5432
PGUSER=portfolio_user
PGPASSWORD=your_secure_password
PGDATABASE=project_zaihash_db

# Application Configuration
NODE_ENV=production
PORT=5000

# Session Security (generate a random string)
SESSION_SECRET=your_session_secret_here_make_it_very_long_and_random
```

**Save the file:** Press `CTRL+O`, then `ENTER`, then `CTRL+X`

## Step 7: Install Application Dependencies

**Location:** `/var/www/project-zaihash`

```bash
npm install
```

## Step 8: Install Database Dependencies

**Location:** `/var/www/project-zaihash`

```bash
npm install drizzle-orm pg @types/pg drizzle-kit
```

## Step 9: Setup Database Schema

**Location:** `/var/www/project-zaihash`

Push the database schema:
```bash
npx drizzle-kit push
```

## Step 10: Build TypeScript Files (if needed)

**Location:** `/var/www/project-zaihash`

```bash
# Compile TypeScript files
npx tsc
```

## Step 11: Test the Application

**Location:** `/var/www/project-zaihash`

```bash
node server.js
```

You should see: `Server running on port 5000`

Stop the test with `CTRL+C`

## Step 12: Configure PM2

**Location:** `/var/www/project-zaihash`

Create PM2 configuration:
```bash
nano ecosystem.config.js
```

Add this configuration:
```javascript
module.exports = {
  apps: [{
    name: 'project-zaihash',
    script: 'server.js',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: 'postgresql://portfolio_user:your_secure_password@localhost:5432/project_zaihash_db',
      PGHOST: 'localhost',
      PGPORT: 5432,
      PGUSER: 'portfolio_user',
      PGPASSWORD: 'your_secure_password',
      PGDATABASE: 'project_zaihash_db',
      SESSION_SECRET: 'your_session_secret_here_make_it_very_long_and_random'
    }
  }]
};
```

**Save the file:** Press `CTRL+O`, then `ENTER`, then `CTRL+X`

## Step 13: Start Application with PM2

**Location:** `/var/www/project-zaihash`

```bash
pm2 start ecosystem.config.js
pm2 save
```

Setup PM2 to start on boot:
```bash
pm2 startup
```
Copy and run the command it shows you (starts with `sudo env PATH=...`)

## Step 14: Configure Nginx

**Location:** `/var/www/project-zaihash`

Create Nginx configuration:
```bash
sudo nano /etc/nginx/sites-available/project-zaihash
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com;  # Replace with your domain or server IP
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # Serve static assets directly (optional optimization)
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        root /var/www/project-zaihash;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
```

**Save the file:** Press `CTRL+O`, then `ENTER`, then `CTRL+X`

## Step 15: Enable Nginx Site

**Location:** `/var/www/project-zaihash`

```bash
sudo ln -s /etc/nginx/sites-available/project-zaihash /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
```

Test and reload Nginx:
```bash
sudo nginx -t
sudo systemctl reload nginx
```

## Step 16: Configure Firewall

**Location:** `/var/www/project-zaihash`

```bash
sudo ufw enable
sudo ufw allow 22,80,443/tcp
```

## Step 17: Setup SSL (Optional but Recommended)

**Location:** `/var/www/project-zaihash`

Install Certbot:
```bash
sudo apt install certbot python3-certbot-nginx
```

Get SSL certificate:
```bash
sudo certbot --nginx -d your-domain.com
```

## Step 18: Verify Everything Works

**Location:** `/var/www/project-zaihash`

Check PM2 status:
```bash
pm2 status
```

Check if port 5000 is listening:
```bash
ss -tlnp | grep :5000
```

Test local connection:
```bash
curl http://localhost:5000
```

Test through Nginx:
```bash
curl http://localhost:80
```

## Step 19: Access Your Portfolio

Open your web browser and go to:
- `http://your-domain.com` (if you have a domain)
- `http://your-server-ip` (if using IP address)

You should see your Project Zaihash website!

## Management Commands

### View Application Status
**Location:** `/var/www/project-zaihash`
```bash
pm2 status
```

### View Application Logs
**Location:** `/var/www/project-zaihash`
```bash
pm2 logs project-zaihash
```

### Restart Application
**Location:** `/var/www/project-zaihash`
```bash
pm2 restart project-zaihash
```

### Stop Application
**Location:** `/var/www/project-zaihash`
```bash
pm2 stop project-zaihash
```

### Restart Nginx
**Location:** Any directory
```bash
sudo systemctl restart nginx
```

### View Nginx Logs
**Location:** Any directory
```bash
sudo tail -f /var/log/nginx/error.log
```

### Update Application
**Location:** `/var/www/project-zaihash`
```bash
# Pull latest changes (if using Git)
git pull origin main

# Install any new dependencies
npm install

# Rebuild TypeScript (if needed)
npx tsc

# Push any database schema changes
npx drizzle-kit push

# Restart the application
pm2 restart project-zaihash
```

## Troubleshooting

### Application Won't Start
- Check PM2 logs: `pm2 logs project-zaihash`
- Check if database is running: `sudo systemctl status postgresql`
- Test database connection: `psql -h localhost -U portfolio_user -d project_zaihash_db`

### Can't Access Website
- Check if application is running: `pm2 status`
- Check if port 5000 is open: `ss -tlnp | grep :5000`
- Check Nginx status: `sudo systemctl status nginx`
- Check firewall: `sudo ufw status`

### Database Connection Issues
- Check PostgreSQL is running: `sudo systemctl status postgresql`
- Verify database exists: `sudo -u postgres psql -l`
- Test connection: `psql -h localhost -U portfolio_user -d project_zaihash_db`

### TypeScript Compilation Issues
- Check if TypeScript is installed: `npx tsc --version`
- Manually compile: `npx tsc`
- Check for syntax errors in `.ts` files

## Security Best Practices

1. **Change default passwords** - Use strong, unique passwords
2. **Keep system updated** - Run `sudo apt update && sudo apt upgrade` regularly
3. **Use SSL** - Always use HTTPS in production
4. **Monitor logs** - Check application and system logs regularly
5. **Backup database** - Create regular database backups
6. **Limit SSH access** - Use key-based authentication and disable password login

## Backup Your Database

### Create a backup:
```bash
pg_dump -h localhost -U portfolio_user project_zaihash_db > backup_$(date +%Y%m%d_%H%M%S).sql
```

### Restore from backup:
```bash
psql -h localhost -U portfolio_user -d project_zaihash_db < backup_file.sql
```

## Performance Optimization

### Enable Gzip Compression in Nginx
Add to your Nginx configuration:
```nginx
gzip on;
gzip_types text/plain text/css application/json application/javascript text/xml application/xml text/javascript;
```

### Set up Log Rotation for PM2
```bash
pm2 install pm2-logrotate
```

## That's It! 🎉

Your Project Zaihash is now running in production!

Your portfolio features:
- ✅ Responsive web design
- ✅ Project showcase with filtering
- ✅ Contact form functionality
- ✅ Admin panel for content management
- ✅ Analytics tracking
- ✅ Database-backed storage
- ✅ Professional deployment

For help or updates, refer to this guide or check the project documentation.