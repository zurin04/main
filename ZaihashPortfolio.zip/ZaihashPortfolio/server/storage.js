const postgres = require('postgres');

// Database connection
const sql = postgres(process.env.DATABASE_URL || 'postgresql://portfolio_user:password@localhost:5432/project_zaihash_db');

class DatabaseStorage {
  constructor() {
    this.initializeData();
  }

  async initializeData() {
    try {
      // Check if we have any projects, if not, add sample data
      const existingProjects = await sql`SELECT COUNT(*) as count FROM projects`;
      if (existingProjects[0].count == 0) {
        await sql`
          INSERT INTO projects (title, description, url, tags, category, featured, view_count) VALUES
          ('AI-Powered Web Scraper', 'Advanced web scraping tool with AI content analysis and data extraction capabilities.', 'https://github.com/zaihash/ai-scraper', 'AI,Python,Web Scraping,Machine Learning', 'AI Tools', true, 127),
          ('Blockchain Analytics Dashboard', 'Real-time blockchain transaction analysis with smart contract interaction tracking.', 'https://github.com/zaihash/blockchain-analytics', 'Blockchain,Web3,React,TypeScript', 'Web3', true, 89),
          ('Neural Network Visualizer', 'Interactive visualization tool for understanding neural network architectures and training processes.', 'https://github.com/zaihash/neural-viz', 'Machine Learning,Visualization,Python,TensorFlow', 'AI Tools', false, 156)
        `;
      }
    } catch (error) {
      console.log('Note: Database not available, using fallback data');
    }
  }

  // Projects
  async getProjects() {
    try {
      const projects = await sql`SELECT * FROM projects ORDER BY created_at DESC`;
      return projects.map(p => ({
        ...p,
        tags: typeof p.tags === 'string' ? p.tags.split(',') : p.tags,
        createdAt: p.created_at,
        updatedAt: p.updated_at,
        viewCount: p.view_count
      }));
    } catch (error) {
      console.error('Database error:', error);
      return [];
    }
  }

  async getProjectById(id) {
    try {
      const projects = await sql`SELECT * FROM projects WHERE id = ${id}`;
      if (projects.length === 0) return undefined;
      const project = projects[0];
      return {
        ...project,
        tags: typeof project.tags === 'string' ? project.tags.split(',') : project.tags,
        createdAt: project.created_at,
        updatedAt: project.updated_at,
        viewCount: project.view_count
      };
    } catch (error) {
      console.error('Database error:', error);
      return undefined;
    }
  }

  async createProject(projectData) {
    try {
      const tags = Array.isArray(projectData.tags) ? projectData.tags.join(',') : projectData.tags;
      const projects = await sql`
        INSERT INTO projects (title, description, url, tags, category, featured, view_count) 
        VALUES (${projectData.title}, ${projectData.description}, ${projectData.url}, ${tags}, ${projectData.category}, ${projectData.featured || false}, ${0})
        RETURNING *
      `;
      const project = projects[0];
      return {
        ...project,
        tags: typeof project.tags === 'string' ? project.tags.split(',') : project.tags,
        createdAt: project.created_at,
        updatedAt: project.updated_at,
        viewCount: project.view_count
      };
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }

  async updateProject(id, updates) {
    try {
      const tags = Array.isArray(updates.tags) ? updates.tags.join(',') : updates.tags;
      const updateData = { ...updates };
      if (tags) updateData.tags = tags;
      if (updateData.viewCount !== undefined) {
        updateData.view_count = updateData.viewCount;
        delete updateData.viewCount;
      }
      
      const projects = await sql`
        UPDATE projects 
        SET ${sql(updateData)}, updated_at = NOW()
        WHERE id = ${id}
        RETURNING *
      `;
      
      if (projects.length === 0) throw new Error('Project not found');
      const project = projects[0];
      return {
        ...project,
        tags: typeof project.tags === 'string' ? project.tags.split(',') : project.tags,
        createdAt: project.created_at,
        updatedAt: project.updated_at,
        viewCount: project.view_count
      };
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }

  async deleteProject(id) {
    try {
      await sql`DELETE FROM projects WHERE id = ${id}`;
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }

  // Contact Submissions
  async getContactSubmissions() {
    try {
      const submissions = await sql`SELECT * FROM contact_submissions ORDER BY created_at DESC`;
      return submissions.map(s => ({
        ...s,
        createdAt: s.created_at
      }));
    } catch (error) {
      console.error('Database error:', error);
      return [];
    }
  }

  async getContactSubmissionById(id) {
    try {
      const submissions = await sql`SELECT * FROM contact_submissions WHERE id = ${id}`;
      if (submissions.length === 0) return undefined;
      const submission = submissions[0];
      return {
        ...submission,
        createdAt: submission.created_at
      };
    } catch (error) {
      console.error('Database error:', error);
      return undefined;
    }
  }

  async createContactSubmission(submissionData) {
    try {
      const submissions = await sql`
        INSERT INTO contact_submissions (name, email, subject, message, status) 
        VALUES (${submissionData.name}, ${submissionData.email}, ${submissionData.subject}, ${submissionData.message}, ${'new'})
        RETURNING *
      `;
      const submission = submissions[0];
      return {
        ...submission,
        createdAt: submission.created_at
      };
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }

  async updateContactSubmissionStatus(id, status) {
    try {
      const submissions = await sql`
        UPDATE contact_submissions 
        SET status = ${status}
        WHERE id = ${id}
        RETURNING *
      `;
      
      if (submissions.length === 0) throw new Error('Contact submission not found');
      const submission = submissions[0];
      return {
        ...submission,
        createdAt: submission.created_at
      };
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }

  async deleteContactSubmission(id) {
    try {
      await sql`DELETE FROM contact_submissions WHERE id = ${id}`;
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }

  // Analytics
  async createAnalyticsEvent(eventData) {
    try {
      const events = await sql`
        INSERT INTO analytics (event, data, user_agent, ip_address) 
        VALUES (${eventData.event}, ${eventData.data}, ${eventData.userAgent}, ${eventData.ipAddress})
        RETURNING *
      `;
      const event = events[0];
      return {
        ...event,
        createdAt: event.created_at
      };
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }

  async getAnalytics(limit = 100) {
    try {
      const analytics = await sql`SELECT * FROM analytics ORDER BY created_at DESC LIMIT ${limit}`;
      return analytics.map(a => ({
        ...a,
        createdAt: a.created_at
      }));
    } catch (error) {
      console.error('Database error:', error);
      return [];
    }
  }
}

const storage = new DatabaseStorage();
module.exports = { storage };