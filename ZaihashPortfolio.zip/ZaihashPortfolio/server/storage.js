// Simple in-memory storage for now - will replace with database later
class MemoryStorage {
  constructor() {
    this.projects = [
      {
        id: 1,
        title: "AI-Powered Web Scraper",
        description: "Advanced web scraping tool with AI content analysis and data extraction capabilities.",
        url: "https://github.com/zaihash/ai-scraper",
        tags: ["AI", "Python", "Web Scraping", "Machine Learning"],
        category: "AI Tools",
        featured: true,
        viewCount: 127,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        title: "Blockchain Analytics Dashboard",
        description: "Real-time blockchain transaction analysis with smart contract interaction tracking.",
        url: "https://github.com/zaihash/blockchain-analytics",
        tags: ["Blockchain", "Web3", "React", "TypeScript"],
        category: "Web3",
        featured: true,
        viewCount: 89,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 3,
        title: "Neural Network Visualizer",
        description: "Interactive visualization tool for understanding neural network architectures and training processes.",
        url: "https://github.com/zaihash/neural-viz",
        tags: ["Machine Learning", "Visualization", "Python", "TensorFlow"],
        category: "AI Tools",
        featured: false,
        viewCount: 156,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
    
    this.contactSubmissions = [
      {
        id: 1,
        name: "Alex Johnson",
        email: "alex@example.com",
        message: "Interested in collaborating on AI projects",
        status: "new",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
    
    this.analytics = [];
    this.nextProjectId = 4;
    this.nextSubmissionId = 2;
    this.nextAnalyticsId = 1;
  }

  // Projects
  async getProjects() {
    return this.projects;
  }

  async getProjectById(id) {
    return this.projects.find(p => p.id === id);
  }

  async createProject(projectData) {
    const project = {
      id: this.nextProjectId++,
      ...projectData,
      viewCount: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.projects.push(project);
    return project;
  }

  async updateProject(id, updates) {
    const index = this.projects.findIndex(p => p.id === id);
    if (index === -1) throw new Error('Project not found');
    
    this.projects[index] = {
      ...this.projects[index],
      ...updates,
      updatedAt: new Date()
    };
    return this.projects[index];
  }

  async deleteProject(id) {
    const index = this.projects.findIndex(p => p.id === id);
    if (index === -1) throw new Error('Project not found');
    this.projects.splice(index, 1);
  }

  // Contact Submissions
  async getContactSubmissions() {
    return this.contactSubmissions;
  }

  async getContactSubmissionById(id) {
    return this.contactSubmissions.find(s => s.id === id);
  }

  async createContactSubmission(submissionData) {
    const submission = {
      id: this.nextSubmissionId++,
      ...submissionData,
      status: 'new',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.contactSubmissions.push(submission);
    return submission;
  }

  async updateContactSubmissionStatus(id, status) {
    const index = this.contactSubmissions.findIndex(s => s.id === id);
    if (index === -1) throw new Error('Contact submission not found');
    
    this.contactSubmissions[index] = {
      ...this.contactSubmissions[index],
      status,
      updatedAt: new Date()
    };
    return this.contactSubmissions[index];
  }

  async deleteContactSubmission(id) {
    const index = this.contactSubmissions.findIndex(s => s.id === id);
    if (index === -1) throw new Error('Contact submission not found');
    this.contactSubmissions.splice(index, 1);
  }

  // Analytics
  async createAnalyticsEvent(eventData) {
    const event = {
      id: this.nextAnalyticsId++,
      ...eventData,
      createdAt: new Date()
    };
    this.analytics.push(event);
    return event;
  }

  async getAnalytics(limit = 100) {
    return this.analytics
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, limit);
  }
}

const storage = new MemoryStorage();
module.exports = { storage };