// Initialize the Web3-themed application
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather Icons
    feather.replace();
    
    // Initialize all functionality
    initializeParticles();
    initializeNavigation();
    loadProjects();
    initializeProjectFilters();
    initializeContactForm();
    initializeScrollAnimations();
    initializeMobileMenu();
    initializeWeb3Animations();
    initializeAnimationToggle();
});

// Particles.js initialization for Web3 background
function initializeParticles() {
    if (typeof particlesJS !== 'undefined') {
        particlesJS('particles-js', {
            particles: {
                number: { value: 80, density: { enable: true, value_area: 800 } },
                color: { value: ['#00D4FF', '#7B2CBF', '#FF2E82'] },
                shape: { 
                    type: 'circle',
                    stroke: { width: 1, color: '#00D4FF' }
                },
                opacity: {
                    value: 0.5,
                    random: true,
                    anim: { enable: true, speed: 1, opacity_min: 0.1 }
                },
                size: {
                    value: 3,
                    random: true,
                    anim: { enable: true, speed: 2, size_min: 0.1 }
                },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: '#00D4FF',
                    opacity: 0.4,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 2,
                    direction: 'none',
                    random: false,
                    straight: false,
                    out_mode: 'out',
                    bounce: false
                }
            },
            interactivity: {
                detect_on: 'canvas',
                events: {
                    onhover: { enable: false, mode: 'repulse' },
                    onclick: { enable: false, mode: 'push' },
                    resize: true
                },
                modes: {
                    grab: { distance: 0, line_linked: { opacity: 0 } },
                    bubble: { distance: 0, size: 0, duration: 0, opacity: 0, speed: 0 },
                    repulse: { distance: 0, duration: 0 },
                    push: { particles_nb: 0 },
                    remove: { particles_nb: 0 }
                }
            },
            retina_detect: true
        });
    }
}

// Web3 Animations using GSAP
function initializeWeb3Animations() {
    if (typeof gsap !== 'undefined') {


        // Floating elements animation
        gsap.to('.animate-float', {
            y: -20,
            duration: 2,
            repeat: -1,
            yoyo: true,
            ease: "power2.inOut"
        });

        // Glitch effect on hover for project cards
        document.querySelectorAll('.project-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                gsap.to(card, {
                    duration: 0.1,
                    x: () => Math.random() * 4 - 2,
                    y: () => Math.random() * 4 - 2,
                    repeat: 5,
                    yoyo: true,
                    ease: "power2.inOut"
                });
            });
        });

        // Typewriter effect
        const typewriterElement = document.querySelector('.animate-typewriter');
        if (typewriterElement) {
            gsap.from(typewriterElement, {
                width: 0,
                duration: 3,
                ease: "steps(40)"
            });
        }
    }
}

// Animation toggle functionality
function initializeAnimationToggle() {
    const toggleBtn = document.getElementById('animation-toggle');
    if (!toggleBtn) return;
    
    let animationsEnabled = true;

    toggleBtn.addEventListener('click', function() {
        animationsEnabled = !animationsEnabled;
        
        if (animationsEnabled) {
            document.body.style.animation = '';
            const particlesContainer = document.querySelector('#particles-js');
            if (particlesContainer) {
                particlesContainer.style.display = 'block';
            }
            const eyeIcon = this.querySelector('i');
            if (eyeIcon) {
                eyeIcon.setAttribute('data-feather', 'eye');
            }
            initializeParticles();
        } else {
            document.body.style.animation = 'none';
            const particlesContainer = document.querySelector('#particles-js');
            if (particlesContainer) {
                particlesContainer.style.display = 'none';
            }
            const eyeIcon = this.querySelector('i');
            if (eyeIcon) {
                eyeIcon.setAttribute('data-feather', 'eye-off');
            }
        }
        
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    });
}

// Navigation functionality
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('section');
    
    // Smooth scrolling for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 80; // Account for fixed navbar
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                const mobileMenu = document.getElementById('mobile-menu');
                if (!mobileMenu.classList.contains('hidden')) {
                    mobileMenu.classList.add('hidden');
                }
            }
        });
    });
    
    // Active section highlighting
    window.addEventListener('scroll', function() {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.clientHeight;
            if (window.pageYOffset >= sectionTop && window.pageYOffset < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').substring(1) === current) {
                link.classList.add('active');
            }
        });
    });
}

// Mobile menu functionality
function initializeMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
            
            // Toggle menu icon
            const icon = this.querySelector('i');
            if (icon) {
                if (mobileMenu.classList.contains('hidden')) {
                    icon.setAttribute('data-feather', 'menu');
                } else {
                    icon.setAttribute('data-feather', 'x');
                }
            }
            if (typeof feather !== 'undefined') {
                feather.replace();
            }
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!mobileMenuBtn.contains(e.target) && !mobileMenu.contains(e.target)) {
                mobileMenu.classList.add('hidden');
                const icon = mobileMenuBtn.querySelector('i');
                if (icon) {
                    icon.setAttribute('data-feather', 'menu');
                }
                if (typeof feather !== 'undefined') {
                    feather.replace();
                }
            }
        });
    }
}

// Project filtering functionality
function initializeProjectFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Update active filter button
            filterBtns.forEach(b => b.classList.remove('active', 'bg-blue-600', 'text-white'));
            filterBtns.forEach(b => b.classList.add('bg-white', 'text-gray-600'));
            
            this.classList.remove('bg-white', 'text-gray-600');
            this.classList.add('active', 'bg-blue-600', 'text-white');
            
            // Filter projects
            projectCards.forEach(card => {
                const tags = card.getAttribute('data-tags');
                
                if (filter === 'all' || tags.includes(filter)) {
                    card.style.display = 'block';
                    card.classList.add('animate-fadeInUp');
                } else {
                    card.style.display = 'none';
                    card.classList.remove('animate-fadeInUp');
                }
            });
        });
    });
}

// Contact form functionality
function initializeContactForm() {
    const contactForm = document.getElementById('contact-form');
    const formInputs = contactForm.querySelectorAll('input, textarea');
    const successMessage = document.getElementById('form-success');
    
    // Real-time validation
    formInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            clearError(this);
        });
    });
    
    // Form submission
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        let isValid = true;
        
        // Validate all fields
        formInputs.forEach(input => {
            if (!validateField(input)) {
                isValid = false;
            }
        });
        
        if (isValid) {
            // Simulate form submission
            submitForm();
        }
    });
    
    function validateField(field) {
        const value = field.value.trim();
        const errorElement = field.parentNode.querySelector('.error-message');
        
        // Clear previous error
        errorElement.classList.add('hidden');
        field.classList.remove('border-red-500');
        
        // Required field validation
        if (value === '') {
            showError(field, 'This field is required');
            return false;
        }
        
        // Email validation
        if (field.type === 'email') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                showError(field, 'Please enter a valid email address');
                return false;
            }
        }
        
        // Name validation
        if (field.name === 'name') {
            if (value.length < 2) {
                showError(field, 'Name must be at least 2 characters long');
                return false;
            }
        }
        
        // Subject validation
        if (field.name === 'subject') {
            if (value.length < 5) {
                showError(field, 'Subject must be at least 5 characters long');
                return false;
            }
        }
        
        // Message validation
        if (field.name === 'message') {
            if (value.length < 10) {
                showError(field, 'Message must be at least 10 characters long');
                return false;
            }
        }
        
        return true;
    }
    
    function showError(field, message) {
        const errorElement = field.parentNode.querySelector('.error-message');
        errorElement.textContent = message;
        errorElement.classList.remove('hidden');
        field.classList.add('border-red-500');
    }
    
    function clearError(field) {
        const errorElement = field.parentNode.querySelector('.error-message');
        errorElement.classList.add('hidden');
        field.classList.remove('border-red-500');
    }
    
    async function submitForm() {
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        // Show loading state
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;
        
        try {
            // Get form data
            const formData = new FormData(contactForm);
            const data = {
                name: formData.get('name'),
                email: formData.get('email'),
                message: formData.get('message')
            };
            
            // Submit to API
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            if (response.ok) {
                // Reset form
                contactForm.reset();
                
                // Show success message
                successMessage.classList.remove('hidden');
                
                // Hide success message after 5 seconds
                setTimeout(() => {
                    successMessage.classList.add('hidden');
                }, 5000);
            } else {
                throw new Error('Failed to submit form');
            }
        } catch (error) {
            console.error('Form submission error:', error);
            // Show error message
            const errorMessage = successMessage.cloneNode(true);
            errorMessage.classList.remove('bg-green-500/20', 'border-green-500', 'text-green-400');
            errorMessage.classList.add('bg-red-500/20', 'border-red-500', 'text-red-400');
            errorMessage.querySelector('p').textContent = 'Failed to send message. Please try again.';
            successMessage.parentNode.insertBefore(errorMessage, successMessage);
            errorMessage.classList.remove('hidden');
            
            setTimeout(() => {
                errorMessage.remove();
            }, 5000);
        } finally {
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    }
}

// Scroll animations
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fadeInUp');
            }
        });
    }, observerOptions);
    
    // Observe project cards
    document.querySelectorAll('.project-card').forEach(card => {
        observer.observe(card);
    });
    
    // Observe other animated elements
    document.querySelectorAll('[class*="animate-"]').forEach(element => {
        observer.observe(element);
    });
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Performance optimization
window.addEventListener('scroll', throttle(() => {
    // Throttled scroll handler for performance
}, 100));

// Keyboard accessibility
document.addEventListener('keydown', function(e) {
    // Escape key closes mobile menu
    if (e.key === 'Escape') {
        const mobileMenu = document.getElementById('mobile-menu');
        if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
            mobileMenu.classList.add('hidden');
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            if (mobileMenuBtn) {
                const icon = mobileMenuBtn.querySelector('i');
                if (icon) {
                    icon.setAttribute('data-feather', 'menu');
                }
                if (typeof feather !== 'undefined') {
                    feather.replace();
                }
            }
        }
    }
});

// Add loading state for external links
document.addEventListener('click', function(e) {
    if (e.target.closest('a[href*="://"]')) {
        const link = e.target.closest('a');
        const originalText = link.textContent;
        
        // Add loading state
        link.style.opacity = '0.7';
        link.style.pointerEvents = 'none';
        
        // Reset after a short delay
        setTimeout(() => {
            link.style.opacity = '1';
            link.style.pointerEvents = 'auto';
        }, 1000);
    }
});

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    // Could send error to logging service here
});

// Handle offline state
window.addEventListener('online', function() {
    console.log('Connection restored');
});

window.addEventListener('offline', function() {
    console.log('Connection lost');
});

// Load projects from API
async function loadProjects() {
    try {
        const response = await fetch('/api/public/projects');
        if (response.ok) {
            const projects = await response.json();
            renderProjects(projects);
        }
    } catch (error) {
        console.error('Failed to load projects:', error);
    }
}

// Render projects dynamically
function renderProjects(projects) {
    const projectsContainer = document.querySelector('#projects-grid');
    if (!projectsContainer) return;
    
    // Clear existing project cards (keep filter buttons)
    const existingCards = projectsContainer.querySelectorAll('.project-card');
    existingCards.forEach(card => card.remove());
    
    projects.forEach(project => {
        const projectCard = document.createElement('div');
        projectCard.className = 'project-card bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6';
        projectCard.setAttribute('data-tags', project.tags.join(',').toLowerCase());
        
        projectCard.innerHTML = `
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-xl font-semibold text-gray-900">${project.title}</h3>
                ${project.featured ? '<span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Featured</span>' : ''}
            </div>
            <p class="text-gray-600 mb-4">${project.description}</p>
            <div class="flex flex-wrap gap-2 mb-4">
                ${project.tags.map(tag => 
                    `<span class="tag bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">#${tag}</span>`
                ).join('')}
            </div>
            <div class="flex items-center justify-between">
                <a href="${project.url}" target="_blank" class="btn-primary bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors inline-flex items-center" onclick="trackProjectClick(${project.id})">
                    Visit Project
                    <i data-feather="external-link" class="w-4 h-4 ml-2"></i>
                </a>
                <span class="text-xs text-gray-400">${project.viewCount || 0} views</span>
            </div>
        `;
        
        projectsContainer.appendChild(projectCard);
    });
    
    // Replace feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
    
    // Re-initialize scroll animations for new project cards
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fadeInUp');
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
    
    document.querySelectorAll('.project-card').forEach(card => {
        observer.observe(card);
    });
}

// Track project clicks
async function trackProjectClick(projectId) {
    try {
        await fetch(`/api/track-click/${projectId}`, {
            method: 'POST'
        });
    } catch (error) {
        console.error('Failed to track click:', error);
    }
}
