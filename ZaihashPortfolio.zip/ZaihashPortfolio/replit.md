# Janmark Sebuguero - Project Zaihash Portfolio

## Overview

This is a portfolio website for Janmark Sebuguero's "Project Zaihash" - a developer and AI collaboration portfolio showcasing innovative projects. The site features both a static frontend (SPA) using vanilla HTML, CSS, and JavaScript with TailwindCSS, and a Node.js/Express backend with PostgreSQL database for dynamic functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### Database Migration (January 2025)
- Migrated from Neon Database to standard PostgreSQL for better VPS compatibility
- Updated database configuration to use `postgres` driver instead of `@neondatabase/serverless`
- Created simplified VPS deployment guide (`VPS_DEPLOYMENT_GUIDE.md`)
- Established database tables: users, projects, contact_submissions, analytics
- Successfully tested PostgreSQL connection and schema creation

## System Architecture

### Frontend Architecture
- **Single Page Application (SPA)**: The entire portfolio is contained within a single HTML file with JavaScript handling navigation and interactions
- **Vanilla JavaScript**: No frontend frameworks used - relies on plain JavaScript for all functionality
- **Component-based Structure**: Organized into logical sections (home, about, projects, contact) with dedicated JavaScript functions for each feature
- **Responsive Design**: Mobile-first approach with responsive breakpoints

### Backend Architecture
- **Node.js/Express Server**: Serves static files and provides API endpoints for dynamic functionality
- **PostgreSQL Database**: Standard PostgreSQL setup using `postgres` driver with Drizzle ORM
- **Database Tables**: users, projects, contact_submissions, analytics
- **Environment Variables**: Configured for both development and production deployment

### Styling Framework
- **TailwindCSS**: Primary CSS framework loaded via CDN for utility-first styling
- **Custom CSS**: Additional custom styles in `style.css` for specific animations and theming
- **Google Fonts**: Inter font family for typography
- **Feather Icons**: Icon library for consistent iconography

## Key Components

### 1. Navigation System
- Fixed navigation bar with backdrop blur effect
- Smooth scrolling between sections
- Active section highlighting on scroll
- Mobile hamburger menu for responsive navigation
- Automatic mobile menu closing on link click

### 2. Project Filtering System
- Category-based project filtering functionality
- Dynamic project display based on selected filters
- Smooth transitions between filter states

### 3. Contact Form
- Interactive contact form with validation
- Form submission handling (currently frontend-only)
- User feedback for form interactions

### 4. Scroll Animations
- Intersection Observer API for scroll-based animations
- Progressive content reveal as user scrolls
- Performance-optimized animation triggers

### 5. Mobile Menu
- Responsive mobile navigation
- Toggle functionality for mobile devices
- Smooth transitions and accessibility considerations

## Data Flow

### Static Content Flow
1. HTML structure defines the layout and content sections
2. CSS (TailwindCSS + custom styles) handles visual presentation
3. JavaScript manages interactivity and dynamic behavior
4. All assets are loaded from CDNs or local files

### User Interaction Flow
1. User clicks navigation links → JavaScript handles smooth scrolling
2. User scrolls page → Navigation updates active states
3. User filters projects → JavaScript shows/hides relevant project cards
4. User submits contact form → JavaScript validates and processes form
5. User scrolls → Animations trigger based on viewport intersection

## External Dependencies

### CDN Dependencies
- **TailwindCSS**: `https://cdn.tailwindcss.com` - CSS framework
- **Feather Icons**: `https://unpkg.com/feather-icons` - Icon library
- **Google Fonts**: Inter font family from Google Fonts API

### Browser APIs Used
- **Intersection Observer API**: For scroll-based animations
- **Scroll Events**: For navigation state management
- **DOM Manipulation**: For dynamic content updates
- **Local Storage**: Potentially for user preferences (implementation pending)

## Deployment Strategy

### Static Site Deployment
- **Type**: Static website with no server-side requirements
- **Hosting**: Can be deployed on any static hosting service (Netlify, Vercel, GitHub Pages, etc.)
- **Build Process**: No build step required - files can be served directly
- **CDN Integration**: All external dependencies loaded from CDNs

### File Structure
```
/
├── index.html          # Main HTML file
├── style.css           # Custom CSS styles
├── script.js           # JavaScript functionality
├── favicon.ico         # Site favicon
└── assets/             # Images and other static assets (if any)
```

### Performance Considerations
- Minimal JavaScript bundle size
- CDN-loaded dependencies for fast loading
- Responsive images and optimized assets
- Efficient scroll event handling with throttling

### SEO Optimization
- Proper meta tags for social sharing
- Semantic HTML structure
- Descriptive page titles and descriptions
- Open Graph tags for social media sharing

## Development Notes

### Code Organization
- Modular JavaScript functions for different features
- CSS custom properties for consistent theming
- Clean separation of concerns between HTML, CSS, and JavaScript

### Browser Compatibility
- Modern browser features used (Intersection Observer, backdrop-filter)
- Fallbacks may be needed for older browsers
- Progressive enhancement approach

### Future Enhancements
- Backend integration for contact form submission
- Content Management System integration
- Analytics tracking implementation
- Performance monitoring setup