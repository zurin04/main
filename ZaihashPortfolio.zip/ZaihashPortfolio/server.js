const express = require('express');
const path = require('path');
const cors = require('cors');
const { storage } = require('./server/storage.js');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Serve admin panel at /zai
app.get('/zai', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// API Routes

// Projects API
app.get('/api/projects', async (req, res) => {
    try {
        const projects = await storage.getProjects();
        res.json(projects);
    } catch (error) {
        console.error('Error fetching projects:', error);
        res.status(500).json({ error: 'Failed to fetch projects' });
    }
});

app.get('/api/projects/:id', async (req, res) => {
    try {
        const project = await storage.getProjectById(parseInt(req.params.id));
        if (!project) {
            return res.status(404).json({ error: 'Project not found' });
        }
        res.json(project);
    } catch (error) {
        console.error('Error fetching project:', error);
        res.status(500).json({ error: 'Failed to fetch project' });
    }
});

app.post('/api/projects', async (req, res) => {
    try {
        const project = await storage.createProject(req.body);
        res.status(201).json(project);
    } catch (error) {
        console.error('Error creating project:', error);
        res.status(500).json({ error: 'Failed to create project' });
    }
});

app.put('/api/projects/:id', async (req, res) => {
    try {
        const project = await storage.updateProject(parseInt(req.params.id), req.body);
        res.json(project);
    } catch (error) {
        console.error('Error updating project:', error);
        res.status(500).json({ error: 'Failed to update project' });
    }
});

app.delete('/api/projects/:id', async (req, res) => {
    try {
        await storage.deleteProject(parseInt(req.params.id));
        res.status(204).send();
    } catch (error) {
        console.error('Error deleting project:', error);
        res.status(500).json({ error: 'Failed to delete project' });
    }
});

// Contact Submissions API
app.get('/api/contact-submissions', async (req, res) => {
    try {
        const submissions = await storage.getContactSubmissions();
        res.json(submissions);
    } catch (error) {
        console.error('Error fetching contact submissions:', error);
        res.status(500).json({ error: 'Failed to fetch contact submissions' });
    }
});

app.post('/api/contact-submissions', async (req, res) => {
    try {
        const submission = await storage.createContactSubmission(req.body);
        res.status(201).json(submission);
    } catch (error) {
        console.error('Error creating contact submission:', error);
        res.status(500).json({ error: 'Failed to create contact submission' });
    }
});

app.put('/api/contact-submissions/:id/status', async (req, res) => {
    try {
        const { status } = req.body;
        const submission = await storage.updateContactSubmissionStatus(parseInt(req.params.id), status);
        res.json(submission);
    } catch (error) {
        console.error('Error updating contact submission status:', error);
        res.status(500).json({ error: 'Failed to update contact submission status' });
    }
});

app.delete('/api/contact-submissions/:id', async (req, res) => {
    try {
        await storage.deleteContactSubmission(parseInt(req.params.id));
        res.status(204).send();
    } catch (error) {
        console.error('Error deleting contact submission:', error);
        res.status(500).json({ error: 'Failed to delete contact submission' });
    }
});

// Analytics API
app.get('/api/analytics', async (req, res) => {
    try {
        const analytics = await storage.getAnalytics(100);
        res.json(analytics);
    } catch (error) {
        console.error('Error fetching analytics:', error);
        res.status(500).json({ error: 'Failed to fetch analytics' });
    }
});

app.post('/api/analytics', async (req, res) => {
    try {
        const event = await storage.createAnalyticsEvent(req.body);
        res.status(201).json(event);
    } catch (error) {
        console.error('Error creating analytics event:', error);
        res.status(500).json({ error: 'Failed to create analytics event' });
    }
});

// Social Info API (using a simple in-memory store for this demo)
let socialInfo = {
    twitterUrl: '',
    discordUrl: '',
    githubUrl: '',
    telegramUrl: '',
    contactEmail: '',
    contactPhone: '',
    bioDescription: ''
};

app.get('/api/social-info', (req, res) => {
    res.json(socialInfo);
});

app.put('/api/social-info', (req, res) => {
    socialInfo = { ...socialInfo, ...req.body };
    res.json(socialInfo);
});

// Public API for frontend
app.get('/api/public/projects', async (req, res) => {
    try {
        const projects = await storage.getProjects();
        // Only return public information
        const publicProjects = projects.map(project => ({
            id: project.id,
            title: project.title,
            description: project.description,
            url: project.url,
            tags: project.tags,
            category: project.category,
            featured: project.featured,
            viewCount: project.viewCount
        }));
        res.json(publicProjects);
    } catch (error) {
        console.error('Error fetching public projects:', error);
        res.status(500).json({ error: 'Failed to fetch projects' });
    }
});

// Track project clicks
app.post('/api/track-click/:id', async (req, res) => {
    try {
        const projectId = parseInt(req.params.id);
        
        // Update view count
        const project = await storage.getProjectById(projectId);
        if (project) {
            await storage.updateProject(projectId, { 
                viewCount: (project.viewCount || 0) + 1 
            });
        }
        
        // Create analytics event
        await storage.createAnalyticsEvent({
            event: 'project_click',
            data: JSON.stringify({ projectId }),
            userAgent: req.headers['user-agent'],
            ipAddress: req.ip
        });
        
        res.json({ success: true });
    } catch (error) {
        console.error('Error tracking click:', error);
        res.status(500).json({ error: 'Failed to track click' });
    }
});

// Contact form submission
app.post('/api/contact', async (req, res) => {
    try {
        const submission = await storage.createContactSubmission(req.body);
        
        // Create analytics event
        await storage.createAnalyticsEvent({
            event: 'contact_submit',
            data: JSON.stringify({ submissionId: submission.id }),
            userAgent: req.headers['user-agent'],
            ipAddress: req.ip
        });
        
        res.status(201).json({ success: true, message: 'Message sent successfully!' });
    } catch (error) {
        console.error('Error submitting contact form:', error);
        res.status(500).json({ error: 'Failed to submit contact form' });
    }
});

// Default route serves the main portfolio
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
});

module.exports = app;